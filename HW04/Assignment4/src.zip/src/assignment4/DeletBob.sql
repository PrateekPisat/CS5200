delete from Follows 
where Followee_id = 6 or Follower_id = 6;

delete from Tweets
where user_id = 6;

delete from Users
where user_id = 6;
